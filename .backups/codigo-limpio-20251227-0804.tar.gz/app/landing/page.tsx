'use client';

import { LandingPageContent } from '@/components/landing/LandingPageContent';

export default function LandingPage() {
  return <LandingPageContent />;
}
